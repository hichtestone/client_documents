<?php

namespace App\Form;

use App\Entity\Infrastructure;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;


class InfrastructureType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('site')
            ->add('nomSvr')
            ->add('OS')
            ->add('CPU_PROC')
            ->add('RAM')
            ->add('totalDisque')
            ->add('DisqueUsed')
            ->add('IP')
            ->add('HYPERV',ChoiceType::class,[
                'choices' => [
                    'VM' => ['VM' => 'Machine Virtuel'],
                    'HYPERV' => ['HYPERV' => 'Hyperviseur'],
                ],
            ])
            ->add('nominal')

        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Infrastructure::class,
        ]);
    }
}
