<?php

namespace App\Service\AuditTrail;

use Exception;

class AuditTrailException extends Exception
{
}
